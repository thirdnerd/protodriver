-- Authoritative device-1 generated-graph helpers.
--
-- This module makes the predecessor TypeScript builder's author conveniences
-- legible in the settled Lua authored-value vocabulary.

local M = {}

function M.bytes(...)
  return string.char(...)
end

function M.byte_value(raw)
  return pdrv.bytes(raw)
end

function M.number(value)
  return value + 0.0
end

function M.array(values)
  return pdrv.array(values)
end

function M.constant(name, offset_bytes, raw)
  return {
    kind = "constant",
    name = name,
    offsetBytes = M.number(offset_bytes),
    bytes = M.byte_value(raw),
  }
end

function M.integer(name, offset_bytes, encoding, unit)
  local field = {
    kind = "integer",
    name = name,
    offsetBytes = M.number(offset_bytes),
    encoding = encoding,
  }
  if unit ~= nil then field.unit = unit end
  return field
end

function M.byte_field(name, offset_bytes, length)
  return {
    kind = "bytes",
    name = name,
    offsetBytes = M.number(offset_bytes),
    length = length,
  }
end

function M.text_field(name, offset_bytes, length)
  return {
    kind = "text",
    name = name,
    offsetBytes = M.number(offset_bytes),
    encoding = "ascii",
    length = length,
    trim = "none",
  }
end

function M.constant_length(byte_count)
  return { kind = "constant", bytes = M.number(byte_count) }
end

function M.binary_layout(minimum, maximum, fields, unclaimed)
  return {
    kind = "binary",
    minimumPayloadBytes = M.number(minimum),
    maximumPayloadBytes = M.number(maximum),
    fields = M.array(fields),
    unclaimedBytes = unclaimed,
  }
end

function M.message(name, identity, minimum, maximum, fields)
  return {
    name = name,
    identity = identity,
    layout = M.binary_layout(minimum, maximum, fields, "reject"),
  }
end

function M.fixed_request(raw)
  return M.binary_layout(#raw, #raw, {
    M.constant("request", 0, raw),
  }, "reject")
end

function M.constant_value(value)
  if type(value) == "number" then
    return {
      kind = "constant",
      value = { numericKind = "number", value = M.number(value) },
    }
  end
  return { kind = "constant", value = value }
end

function M.step_path(step, path)
  return { kind = "path", source = { kind = "step", step = step, path = M.array(path) } }
end

function M.item_path(path)
  return { kind = "path", source = { kind = "item", path = M.array(path) } }
end

function M.argument_path(argument)
  return { kind = "path", source = { kind = "argument", argument = argument } }
end

function M.equal(left, right)
  return { kind = "equal", left = left, right = right }
end

function M.protocol_mode(definition)
  local binary_requests = {}
  local text_requests = {}
  local routing_commands = {}
  for command_name in pdrv.record_fields(definition.commands) do
    local command = definition.commands[command_name]
    if command.request.kind == "binary" then
      M.append(binary_requests, { command = command_name, layout = command.request.layout })
    else
      M.append(text_requests, {
        command = command_name,
        segments = command.request.segments,
        maximumPayloadBytes = command.request.maximumPayloadBytes,
      })
    end
    local responses = {}
    for _, response in ipairs(command.responses) do M.append(responses, response.identity) end
    M.append(routing_commands, {
      command = command_name,
      responses = M.array(responses),
      completion = command.completion,
      echo = command.echo,
    })
  end
  return {
    messageSelection = definition.messageSelection,
    messages = definition.messages,
    binaryRequests = M.array(binary_requests),
    textRequests = M.array(text_requests),
    inboundReassembly = definition.inboundReassembly,
    routing = {
      alwaysEvent = definition.routing.alwaysEvent,
      contextDependent = definition.routing.contextDependent,
      maximumConsecutiveUnknownMessages = definition.routing.maximumConsecutiveUnknownMessages,
      unknownMessageDisposition = definition.routing.unknownMessageDisposition,
      commands = M.array(routing_commands),
    },
    correlation = definition.correlation,
    recovery = definition.recovery,
  }
end

function M.append(target, value)
  target[#target + 1] = value
end

function M.append_all(target, source)
  for _, value in ipairs(source) do M.append(target, value) end
  return target
end

return M

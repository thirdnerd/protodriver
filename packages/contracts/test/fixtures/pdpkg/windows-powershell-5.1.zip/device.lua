-- Authoritative generated-manifest source for the device-1 module.
-- The second return is the callable export table; this declaration has none.

local G = require("graph.lua")

local function response(opcode)
  return { kind = "response", opcode = opcode }
end

local ACK = response("ack")
local IDENTIFY = response("identify")
local STATUS = response("status")
local QUERY = response("query")
local READ = response("read")
local HANDSHAKE = response("transfer-handshake")
local REJECTED = response("rejected")

local fixed_byte = { kind = "fixed", id = "byte" }
local tenth_hertz = { kind = "fixed", id = "tenth-hertz" }
local hertz = { kind = "fixed", id = "hertz" }
local EMPTY_ARRAY = G.array({})

local function tone_field(name, label, offset_bytes)
  return {
    name = name,
    label = label,
    kind = "tagged-union",
    offsetBytes = G.number(offset_bytes),
    byteLength = 2.0,
    discriminator = {
      encoding = "u16le",
      variants = G.array({
        {
          name = "none",
          label = "No tone",
          mask = G.number(0xffff),
          equals = G.number(0xffff),
          constraints = EMPTY_ARRAY,
          layout = G.binary_layout(2, 2, {
            G.constant("wire", 0, G.bytes(0xff, 0xff)),
          }, "reject"),
        },
        {
          name = "dcs",
          label = "DCS",
          mask = G.number(0x8000),
          equals = G.number(0x8000),
          constraints = G.array({
            { kind = "packed-decimal-digits", path = G.array({ "code" }), digits = 3.0 },
            { kind = "exact", path = G.array({ "reserved" }), value = 0.0 },
          }),
          layout = G.binary_layout(2, 2, {
            { name = "code", label = "DCS code", kind = "bit-field", valueKind = "integer", offsetBytes = 0.0, containerEncoding = "u16le", leastSignificantBit = 0.0, widthBits = 12.0, undeclaredBits = "reject" },
            { name = "reserved", kind = "bit-field", valueKind = "integer", offsetBytes = 0.0, containerEncoding = "u16le", leastSignificantBit = 12.0, widthBits = 2.0, undeclaredBits = "reject" },
            {
              name = "polarity", label = "DCS polarity", kind = "bit-field",
              valueKind = "member", offsetBytes = 0.0, containerEncoding = "u16le",
              leastSignificantBit = 14.0, widthBits = 1.0, undeclaredBits = "reject",
              members = G.array({
                { wireValue = 0.0, name = "normal", label = "Normal" },
                { wireValue = 1.0, name = "inverted", label = "Inverted" },
              }),
            },
            {
              name = "marker", kind = "bit-field", valueKind = "member",
              offsetBytes = 0.0, containerEncoding = "u16le", leastSignificantBit = 15.0,
              widthBits = 1.0, undeclaredBits = "reject",
              members = G.array({ { wireValue = 1.0, name = "dcs" } }),
            },
          }, "reject"),
        },
        {
          name = "ctcss",
          label = "CTCSS",
          mask = G.number(0x8000),
          equals = 0.0,
          constraints = G.array({
            { kind = "integer-range", path = G.array({ "tenthsHz" }), minimum = 670.0, maximum = 2541.0 },
          }),
          layout = G.binary_layout(2, 2, {
            {
              name = "tenthsHz", label = "CTCSS frequency", kind = "packed-bcd",
              offsetBytes = 0.0, byteLength = 2.0, byteOrder = "little-endian",
              numericType = "number", unit = tenth_hertz, invalidDigits = "reject",
              specialWireValues = EMPTY_ARRAY,
            },
          }, "reject"),
        },
      }),
      fallback = "unrecognised",
    },
  }
end

local CHANNEL_FIELDS = {
  {
    name = "receiveFrequency", label = "Receive frequency", kind = "packed-bcd",
    offsetBytes = 0.0, byteLength = 4.0, byteOrder = "little-endian",
    numericType = "number",
    scale = { numerator = 10.0, denominator = 1.0, offset = 0.0, quantization = "reject-inexact" },
    unit = hertz, invalidDigits = "reject",
    specialWireValues = G.array({
      { bytes = G.byte_value(G.bytes(0xff, 0xff, 0xff, 0xff)), name = "erased", label = "Erased" },
    }),
  },
  {
    name = "transmitFrequency", label = "Transmit frequency", kind = "packed-bcd",
    offsetBytes = 4.0, byteLength = 4.0, byteOrder = "little-endian",
    numericType = "number",
    scale = { numerator = 10.0, denominator = 1.0, offset = 0.0, quantization = "reject-inexact" },
    unit = hertz, invalidDigits = "reject",
    specialWireValues = G.array({
      { bytes = G.byte_value(G.bytes(0xff, 0xff, 0xff, 0xff)), name = "erased", label = "Erased" },
    }),
  },
  tone_field("receiveTone", "Receive tone", 9),
  tone_field("transmitTone", "Transmit tone", 11),
  { name = "busyChannelLock", label = "Busy channel lock", kind = "bit-field", valueKind = "boolean", offsetBytes = 13.0, containerEncoding = "u8", leastSignificantBit = 6.0, widthBits = 1.0, undeclaredBits = "preserve" },
  {
    name = "pttId", label = "PTT-ID", kind = "bit-field", valueKind = "member",
    offsetBytes = 13.0, containerEncoding = "u8", leastSignificantBit = 4.0,
    widthBits = 2.0, undeclaredBits = "preserve",
    members = G.array({
      { wireValue = 0.0, name = "off", label = "Off" },
      { wireValue = 1.0, name = "bot", label = "BOT" },
      { wireValue = 2.0, name = "eot", label = "EOT" },
      { wireValue = 3.0, name = "both", label = "Both" },
    }),
  },
  {
    name = "bandwidth", label = "Bandwidth", kind = "bit-field", valueKind = "member",
    offsetBytes = 13.0, containerEncoding = "u8", leastSignificantBit = 2.0,
    widthBits = 2.0, undeclaredBits = "preserve",
    members = G.array({
      { wireValue = 0.0, name = "narrow", label = "Narrow" },
      { wireValue = 1.0, name = "wide", label = "Wide" },
      { wireValue = 2.0, name = "unassigned-10", label = "Unassigned (10)" },
      { wireValue = 3.0, name = "unassigned-11", label = "Unassigned (11)" },
    }),
  },
  {
    name = "power", label = "Power", kind = "bit-field", valueKind = "member",
    offsetBytes = 13.0, containerEncoding = "u8", leastSignificantBit = 0.0,
    widthBits = 2.0, undeclaredBits = "preserve",
    members = G.array({
      { wireValue = 0.0, name = "low", label = "Low" },
      { wireValue = 1.0, name = "medium", label = "Medium" },
      { wireValue = 2.0, name = "high", label = "High" },
      { wireValue = 3.0, name = "unassigned-11", label = "Unassigned (11)" },
    }),
  },
  { name = "signallingGroup", label = "Signalling group", kind = "bit-field", valueKind = "integer", offsetBytes = 14.0, containerEncoding = "u8", leastSignificantBit = 4.0, widthBits = 4.0, undeclaredBits = "preserve" },
  { name = "frequencyHopping", label = "Frequency hopping", kind = "bit-field", valueKind = "boolean", offsetBytes = 14.0, containerEncoding = "u8", leastSignificantBit = 1.0, widthBits = 1.0, undeclaredBits = "preserve" },
  { name = "scanAdd", label = "Scan add", kind = "bit-field", valueKind = "boolean", offsetBytes = 14.0, containerEncoding = "u8", leastSignificantBit = 0.0, widthBits = 1.0, undeclaredBits = "preserve" },
}
local CHANNEL_LAYOUT = G.binary_layout(16, 16, CHANNEL_FIELDS, "preserve")

local function exact_exchange(command, frame_bytes)
  return { command = command, response = { kind = "exact", frameBytes = G.number(frame_bytes) } }
end

local function variable_exchange(command, prefix, header_bytes, offset_bytes, maximum_value)
  return {
    command = command,
    response = {
      kind = "prefix-discriminated",
      alternatives = G.array({
        { prefix = G.byte_value(G.bytes(0)), length = { kind = "exact", frameBytes = 1.0 } },
        {
          prefix = G.byte_value(G.bytes(prefix)),
          length = {
            kind = "encoded",
            headerBytes = G.number(header_bytes),
            field = {
              offsetBytes = G.number(offset_bytes), widthBytes = 1.0,
              byteOrder = "little-endian", minimumValue = 0.0,
              maximumValue = G.number(maximum_value),
              frameLengthAdjustmentBytes = G.number(header_bytes),
            },
          },
        },
      }),
    },
  }
end

local PROFILE_CODEC = {
  kind = "fixed-length",
  length = {
    kind = "exchange-directed",
    exchanges = G.array({
      exact_exchange("identify", 8),
      exact_exchange("status", 3),
      exact_exchange("open-info", 1),
      variable_exchange("query", 0x56, 3, 2, 10),
      exact_exchange("open-transfer", 1),
      exact_exchange("transfer-handshake", 8),
      exact_exchange("confirm", 1),
      variable_exchange("read", 0x57, 5, 4, 64),
      exact_exchange("write", 1),
    }),
  },
  maximumFrameBytes = 69.0,
  integrity = { kind = "none" },
  payload = { offsetBytes = 0.0, length = { kind = "frame-remainder", trailingBytes = 0.0 } },
}

local IDENTIFY_MESSAGE = G.message("identify", IDENTIFY, 8, 8, {
  G.constant("ack", 0, G.bytes(0x06)),
  G.text_field("identity", 1, G.constant_length(7)),
})
local STATUS_MESSAGE = G.message("status", STATUS, 3, 3, {
  G.constant("responseCode", 0, G.bytes(0x50)),
  G.byte_field("raw", 1, G.constant_length(2)),
})
local ACK_MESSAGE = G.message("ack", ACK, 1, 1, {
  G.constant("ack", 0, G.bytes(0x06)),
})
local HANDSHAKE_MESSAGE = G.message("transfer-handshake", HANDSHAKE, 8, 8, {
  G.constant("token", 0, G.bytes(0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff)),
})
local QUERY_MESSAGE = G.message("query-response", QUERY, 13, 13, {
  G.constant("responseCode", 0, G.bytes(0x56)),
  G.integer("identifier", 1, "u8"),
  G.integer("length", 2, "u8", fixed_byte),
  G.text_field("data", 3, G.constant_length(10)),
})
local READ_MESSAGE = G.message("read-response", READ, 5, 69, {
  G.constant("responseCode", 0, G.bytes(0x57)),
  G.integer("address", 1, "u24le", fixed_byte),
  G.integer("length", 4, "u8", fixed_byte),
  G.byte_field("data", 5, { kind = "decoded-field", field = "length", multiplier = 1.0, adjustmentBytes = 0.0, maximumBytes = 64.0 }),
})
local REJECTED_MESSAGE = G.message("rejected", REJECTED, 1, 1, {
  G.constant("rejected", 0, G.bytes(0)),
})

local one_message = { kind = "one-message", timeoutMs = 300.0 }
local no_echo = { kind = "none" }
local function binary_command(layout, responses)
  return {
    request = { kind = "binary", layout = layout },
    responses = responses,
    completion = one_message,
    echo = no_echo,
  }
end

local COMMANDS = {
  identify = binary_command(G.fixed_request("PSEARCH"), { IDENTIFY_MESSAGE }),
  status = binary_command(G.fixed_request("PASSSTA"), { STATUS_MESSAGE }),
  ["open-info"] = binary_command(G.fixed_request("SYSINFO"), { ACK_MESSAGE }),
  query = binary_command(G.binary_layout(5, 5, {
    G.constant("opcode", 0, G.bytes(0x56)),
    G.constant("padding", 1, G.bytes(0, 0, 0)),
    G.integer("identifier", 4, "u8"),
  }, "reject"), { QUERY_MESSAGE, REJECTED_MESSAGE }),
  ["open-transfer"] = binary_command(G.fixed_request("P13GMRS"), { ACK_MESSAGE }),
  ["transfer-handshake"] = binary_command(G.fixed_request(G.bytes(0x02)), { HANDSHAKE_MESSAGE }),
  confirm = binary_command(G.fixed_request(G.bytes(0x06)), { ACK_MESSAGE }),
  read = binary_command(G.binary_layout(5, 5, {
    G.constant("opcode", 0, G.bytes(0x52)),
    G.integer("address", 1, "u24le", fixed_byte),
    G.integer("length", 4, "u8", fixed_byte),
  }, "reject"), { READ_MESSAGE, REJECTED_MESSAGE }),
  write = binary_command(G.binary_layout(5, 69, {
    G.constant("opcode", 0, G.bytes(0x57)),
    G.integer("address", 1, "u24le", fixed_byte),
    G.integer("length", 4, "u8", fixed_byte),
    G.byte_field("data", 5, { kind = "decoded-field", field = "length", multiplier = 1.0, adjustmentBytes = 0.0, maximumBytes = 64.0 }),
  }, "reject"), { ACK_MESSAGE, REJECTED_MESSAGE }),
}

local PROTOCOL_MODE = G.protocol_mode({
  messageSelection = { kind = "unique-layout-match" },
  messages = G.array({
    IDENTIFY_MESSAGE, STATUS_MESSAGE, ACK_MESSAGE, HANDSHAKE_MESSAGE,
    QUERY_MESSAGE, READ_MESSAGE, REJECTED_MESSAGE,
  }),
  inboundReassembly = pdrv.null,
  commands = COMMANDS,
  routing = {
    alwaysEvent = EMPTY_ARRAY, contextDependent = EMPTY_ARRAY, maximumConsecutiveUnknownMessages = 1.0,
    unknownMessageDisposition = "consume-and-diagnose",
  },
  correlation = { kind = "ordered", maximumCommandsInFlight = 1.0 },
  recovery = {
    kind = "reconnect", reconnectTimeoutMs = 3500.0, reEstablish = true,
    reEstablishmentTimeoutMs = 1300.0,
  },
})

local ESTABLISHMENT = {
  steps = G.array({
    { command = "identify", expectedMessage = IDENTIFY, purpose = "probe" },
    { command = "open-transfer", expectedMessage = ACK, purpose = "entry" },
    { command = "transfer-handshake", expectedMessage = HANDSHAKE, purpose = "entry" },
    { command = "confirm", expectedMessage = ACK, purpose = "entry" },
  }),
}

local CONNECTION = {
  id = "serial",
  acquisitionFilters = G.array({
    { transport = "serial", vendorId = G.number(0x1a86), productId = G.number(0x7523) },
  }),
  transport = {
    kind = "serial", baudRate = 57600.0, dataBits = 8.0,
    parity = "none", stopBits = 1.0, flowControl = "none",
  },
  channels = G.array({ { id = "main", protocolDuplex = "half-duplex" } }),
  codec = PROFILE_CODEC,
  lifecycle = {
    openingDrainQuietMs = 300.0,
    postTerminationSilence = {
      minimumMs = 3000.0, afterAbnormalTermination = true, afterModeExit = true,
    },
  },
}

local READ_RANGE = {
  command = {
    command = "read",
    arguments = {
      address = { kind = "target-offset" },
      length = { kind = "length" },
    },
    expectedMessage = READ,
  },
  followUp = G.array({
    { command = "confirm", arguments = {}, expectedMessage = ACK },
  }),
  responseAssertions = G.array({
    { path = G.array({ "fields", "address" }), equals = "target-offset" },
    { path = G.array({ "fields", "length" }), equals = "length" },
  }),
  settledBytes = { kind = "response-path", path = G.array({ "fields", "data" }) },
}

local WRITE_RANGE = {
  command = {
    command = "write",
    arguments = {
      address = { kind = "target-offset" },
      length = { kind = "length" },
      data = { kind = "source-bytes" },
    },
    expectedMessage = ACK,
  },
  followUp = EMPTY_ARRAY,
  responseAssertions = EMPTY_ARRAY,
  settledBytes = { kind = "request-source" },
}

local MAXIMUM_RANGE_BYTES = 0xffffff
local CHUNK_BYTES = 64
local MAXIMUM_SETTLEMENT_OBSERVATIONS =
  (MAXIMUM_RANGE_BYTES + CHUNK_BYTES - 1) // CHUNK_BYTES
if MAXIMUM_SETTLEMENT_OBSERVATIONS ~= 262144 then
  error("device-1 settlement observation bound drifted")
end

local function parameter(name)
  return { kind = "parameter", parameter = name }
end

local MEMORY_RANGE = {
  parameters = G.array({
    { name = "targetOffset", minimum = 0.0, maximum = G.number(MAXIMUM_RANGE_BYTES), unit = fixed_byte },
    { name = "length", minimum = 1.0, maximum = G.number(MAXIMUM_RANGE_BYTES), unit = fixed_byte },
  }),
  directions = {
    deviceToHost = {
      preparation = EMPTY_ARRAY,
      data = {
        action = "read-range-chunk", maximumWaitMs = 300.0,
        sourceOffset = { kind = "constant", value = 0.0 },
        targetOffset = parameter("targetOffset"), length = parameter("length"),
        maximumChunkBytes = G.number(CHUNK_BYTES), alignmentBytes = 1.0, maximumInFlight = 1.0,
      },
      settlement = {
        kind = "per-action-response", selection = "read-response",
        maximumWaitMs = 300.0, maximumObservations = G.number(MAXIMUM_SETTLEMENT_OBSERVATIONS),
      },
      completion = EMPTY_ARRAY, verification = EMPTY_ARRAY, retry = { kind = "none" }, resume = pdrv.null,
    },
    hostToDevice = {
      writeProtection = { kind = "compare-before-write" },
      preparation = EMPTY_ARRAY,
      data = {
        action = "write-range-chunk", maximumWaitMs = 300.0,
        sourceOffset = { kind = "constant", value = 0.0 },
        targetOffset = parameter("targetOffset"), length = parameter("length"),
        maximumChunkBytes = G.number(CHUNK_BYTES), alignmentBytes = 1.0, maximumInFlight = 1.0,
      },
      settlement = {
        kind = "per-action-response", selection = "write-response",
        maximumWaitMs = 300.0, maximumObservations = G.number(MAXIMUM_SETTLEMENT_OBSERVATIONS),
      },
      completion = EMPTY_ARRAY, verification = EMPTY_ARRAY, retry = { kind = "none" }, resume = pdrv.null,
    },
  },
}

local function tag_read_steps(prefix)
  local steps = {}
  for index = 0, 14 do
    G.append(steps, {
      id = prefix .. "-tag-" .. index,
      kind = "transfer",
      transfer = "memory-range",
      direction = "deviceToHost",
      parameters = {
        targetOffset = G.constant_value(0x1fff + index * 0x1000),
        length = G.constant_value(1),
      },
      retain = { domain = "target" },
    })
  end
  return steps
end

local function select_live_range(prefix)
  local candidates = {}
  for index = 0, 14 do
    candidates["sector-" .. index] = {
      when = G.equal(
        G.step_path(prefix .. "-tag-" .. index, { "domains", "target" }),
        G.constant_value(G.byte_value(G.bytes(0x16)))
      ),
      value = { numericKind = "number", value = (0x1000 + index * 0x1000) + 0.0 },
    }
  end
  return {
    id = prefix .. "-select",
    kind = "select-exactly-one",
    candidates = candidates,
  }
end

local function channel_read_steps(prefix)
  local steps = tag_read_steps(prefix)
  G.append(steps, select_live_range(prefix))
  G.append(steps, {
    id = prefix .. "-sector",
    kind = "transfer",
    transfer = "memory-range",
    direction = "deviceToHost",
    parameters = {
      targetOffset = G.step_path(prefix .. "-select", { "value" }),
      length = G.constant_value(4096),
    },
    retain = { domain = "target" },
  })
  G.append(steps, {
    id = prefix .. "-records",
    kind = "apply-stored-layout",
    source = { step = prefix .. "-sector", domain = "target" },
    layout = "channel", offsetBytes = G.number(0x30), strideBytes = 16.0, count = 250.0,
  })
  return steps
end

local function channel_field_maps()
  local labels = {}
  local fields = {}
  for _, field in ipairs(CHANNEL_FIELDS) do
    labels[field.name] = field.label or field.name
    fields[field.name] = G.item_path({ "fields", field.name })
  end
  return labels, fields
end

local channel_field_labels, channel_fields = channel_field_maps()
local CHANNEL_RECORD_PROJECTION = {
  kind = "record",
  fieldLabels = {
    index = "Channel index", offsetBytes = "Offset",
    sourcePayload = "Source bytes", fields = "Decoded fields",
  },
  fields = {
    index = G.item_path({ "index" }),
    offsetBytes = G.item_path({ "offsetBytes" }),
    sourcePayload = G.item_path({ "sourcePayload" }),
    fields = { kind = "record", fieldLabels = channel_field_labels, fields = channel_fields },
  },
}

local function tag_projection(prefix)
  local labels = {}
  local fields = {}
  for index = 0, 14 do
    local name = "tag" .. index
    labels[name] = "Sector " .. (index + 1) .. " tag"
    fields[name] = G.step_path(prefix .. "-tag-" .. index, { "domains", "target" })
  end
  return { kind = "record", fieldLabels = labels, fields = fields }
end

local function command_step(id, command, arguments, expected_message)
  return {
    id = id,
    kind = "command",
    command = command,
    arguments = arguments,
    expectedMessage = expected_message,
  }
end

local RESTART_CLEANUP_TIMEOUT_MS = 4900.0
local EXCLUSIVE_PROTOCOL_LOCK = G.array({ { name = "protocol", access = "exclusive" } })

local INFO_IDENTIFY = command_step("identify", "identify", {}, IDENTIFY)
local INFO_OPEN = command_step("open-info", "open-info", {}, ACK)
local INFO_FIRMWARE = command_step("firmware", "query", {
  identifier = G.constant_value(1),
}, QUERY)
local INFO_CONFIRM = command_step("confirm-firmware", "confirm", {}, ACK)

local GET_DEVICE_INFO = {
  id = "get_device_info",
  title = "Get device information",
  description = "Read and require identity P13GMRS and firmware V06.03.009, then report the protocol transfer limits.",
  risk = "read-only",
  idempotency = "safe-to-repeat",
  arguments = EMPTY_ARRAY,
  locks = EXCLUSIVE_PROTOCOL_LOCK,
  steps = G.array({
    {
      id = "refresh-information",
      kind = "connection-restart",
      cleanupTimeoutMs = RESTART_CLEANUP_TIMEOUT_MS,
      beforeReestablishment = G.array({
        INFO_IDENTIFY,
        {
          id = "require-identity", kind = "assert",
          condition = G.equal(G.step_path("identify", { "fields", "identity" }), G.constant_value("P13GMRS")),
          failureCode = "device-1.identity-mismatch", message = "identity must be P13GMRS",
        },
        INFO_OPEN,
        INFO_FIRMWARE,
        INFO_CONFIRM,
        {
          id = "require-firmware", kind = "assert",
          condition = G.equal(G.step_path("firmware", { "fields", "data" }), G.constant_value("V06.03.009")),
          failureCode = "device-1.firmware-mismatch", message = "firmware must be V06.03.009",
        },
        { id = "leave-info", kind = "delay", durationMs = 600.0 },
      }),
    },
  }),
  result = {
    kind = "record",
    fieldLabels = {
      identity = "Device identity", firmware = "Firmware version",
      maximumReadLength = "Maximum read length", maximumWriteLength = "Maximum write length",
    },
    fields = {
      identity = G.step_path("identify", { "fields", "identity" }),
      firmware = G.step_path("firmware", { "fields", "data" }),
      maximumReadLength = G.constant_value(64), maximumWriteLength = G.constant_value(64),
    },
  },
}

local STATUS_IDENTIFY = command_step("identify-status", "identify", {}, IDENTIFY)
local STATUS_READ = command_step("status", "status", {}, STATUS)
local GET_STATUS = {
  id = "get_status",
  title = "Get status",
  description = "Read the radio's two opaque status octets. The reference assigns them no meaning.",
  risk = "read-only", idempotency = "safe-to-repeat", arguments = EMPTY_ARRAY,
  locks = EXCLUSIVE_PROTOCOL_LOCK,
  steps = G.array({
    {
      id = "refresh-status", kind = "connection-restart",
      cleanupTimeoutMs = RESTART_CLEANUP_TIMEOUT_MS,
      beforeReestablishment = G.array({
        STATUS_IDENTIFY,
        {
          id = "require-status-identity", kind = "assert",
          condition = G.equal(G.step_path("identify-status", { "fields", "identity" }), G.constant_value("P13GMRS")),
          failureCode = "device-1.identity-mismatch", message = "identity must be P13GMRS",
        },
        STATUS_READ,
      }),
    },
  }),
  result = {
    kind = "record",
    fieldLabels = { raw = "Raw status", observedDuringProbe = "Observed during probe" },
    fields = {
      raw = G.step_path("status", { "fields", "raw" }),
      observedDuringProbe = G.constant_value(false),
    },
  },
}

local PING_READ = command_step("ping-read", "read", {
  address = G.constant_value(0), length = G.constant_value(0),
}, READ)
local PING_CONFIRM = command_step("confirm-ping", "confirm", {}, ACK)
local PING = {
  id = "ping",
  title = "Ping",
  description = "Keep transfer mode active with a zero-length read at address zero and verify the echoed address and length.",
  risk = "read-only", idempotency = "safe-to-repeat", arguments = EMPTY_ARRAY,
  locks = EXCLUSIVE_PROTOCOL_LOCK,
  steps = G.array({
    PING_READ,
    PING_CONFIRM,
    {
      id = "require-ping-address", kind = "assert",
      condition = G.equal(G.step_path("ping-read", { "fields", "address" }), G.constant_value(0)),
      failureCode = "device-1.read-echo-mismatch", message = "ping read must echo address zero",
    },
    {
      id = "require-ping-length", kind = "assert",
      condition = G.equal(G.step_path("ping-read", { "fields", "length" }), G.constant_value(0)),
      failureCode = "device-1.read-echo-mismatch", message = "ping read must echo length zero",
    },
  }),
  result = {
    kind = "record", fieldLabels = { address = "Address", length = "Length" },
    fields = {
      address = G.step_path("ping-read", { "fields", "address" }),
      length = G.step_path("ping-read", { "fields", "length" }),
    },
  },
}

local READ_CHANNELS = {
  id = "read_channel_configuration",
  title = "Read channel configuration",
  description = "Locate the one live configuration sector, retain its 4,096 raw bytes and sector tags, and decode all 250 channel records.",
  risk = "read-only", idempotency = "safe-to-repeat", arguments = EMPTY_ARRAY,
  locks = EXCLUSIVE_PROTOCOL_LOCK,
  steps = G.array(channel_read_steps("read")),
  result = {
    kind = "record",
    fieldLabels = {
      sectorBase = "Sector base", raw = "Raw sector",
      tags = "Sector tags", channels = "Channels",
    },
    fields = {
      sectorBase = G.step_path("read-select", { "value" }),
      raw = G.step_path("read-sector", { "domains", "target" }),
      tags = tag_projection("read"),
      channels = { kind = "repeated-layout", step = "read-records", item = CHANNEL_RECORD_PROJECTION },
    },
  },
}

local CHANNEL_EDIT_FIELDS = G.array({
  "receiveFrequency", "transmitFrequency", "receiveTone", "transmitTone",
  "busyChannelLock", "pttId", "bandwidth", "power", "signallingGroup", "scanAdd",
})

local WRITE_ARGUMENTS = G.array({
  {
    name = "channelIndex", label = "Channel record index",
    description = "Zero-based index of the channel record to edit, from 0 through 249.",
    kind = "integer", minimum = 0.0, maximum = 249.0,
  },
  {
    name = "expectedCurrent", label = "Expected current sector",
    description = "The 4,096-byte raw sector from a current channel read. The write is refused if the device now differs.",
    kind = "byte-source", minimumBytes = 4096.0, maximumBytes = 4096.0,
  },
  {
    name = "edits", label = "Channel fields to change",
    description = "Enable only fields to change. Unselected and undefined stored octets are preserved from the current sector.",
    kind = "stored-layout-edit", layout = "channel", editableFields = CHANNEL_EDIT_FIELDS,
    valueRestrictions = {
      bandwidth = { kind = "members", values = G.array({ "narrow", "wide" }) },
      power = { kind = "members", values = G.array({ "low", "medium", "high" }) },
      signallingGroup = { kind = "integer-range", minimum = 1.0, maximum = 15.0 },
    },
  },
})

local WRITE_STEPS = channel_read_steps("write")
G.append(WRITE_STEPS, {
  id = "write-edit", kind = "edit-stored-layout", sourceStep = "write-records",
  index = G.argument_path("channelIndex"), editsArgument = "edits",
  editableFields = CHANNEL_EDIT_FIELDS,
})
G.append(WRITE_STEPS, {
  id = "write-commit", kind = "transfer", transfer = "memory-range",
  direction = "hostToDevice",
  parameters = {
    targetOffset = G.step_path("write-select", { "value" }),
    length = G.constant_value(4096),
  },
  sourceStep = "write-edit", expectedCurrentArgument = "expectedCurrent", guardStep = "write-sector",
})
G.append(WRITE_STEPS, {
  id = "write-verify", kind = "transfer", transfer = "memory-range",
  direction = "deviceToHost",
  parameters = {
    targetOffset = G.step_path("write-select", { "value" }),
    length = G.constant_value(4096),
  },
  retain = { domain = "target" },
})
G.append(WRITE_STEPS, {
  id = "require-write-verification", kind = "assert",
  condition = G.equal(
    G.step_path("write-verify", { "domains", "target" }),
    G.step_path("write-edit", { "encoded" })
  ),
  failureCode = "device-1.channel-write-verification-mismatch",
  message = "written channel bytes must read back exactly",
})
G.append(WRITE_STEPS, {
  id = "write-verified-records", kind = "apply-stored-layout",
  source = { step = "write-verify", domain = "target" },
  layout = "channel", offsetBytes = G.number(0x30), strideBytes = 16.0, count = 250.0,
})

local WRITE_CHANNELS = {
  id = "write_channel_configuration",
  title = "Guarded channel configuration write",
  description = "Read the live 4,096-byte sector again, refuse a stale expected sector, apply sparse edits to one channel, write the complete sector, and verify it by reading it back. Power loss during the sector rewrite can leave the channel configuration incomplete.",
  risk = "destructive", idempotency = "not-repeatable", arguments = WRITE_ARGUMENTS,
  locks = EXCLUSIVE_PROTOCOL_LOCK,
  steps = G.array(WRITE_STEPS),
  result = {
    kind = "record",
    fieldLabels = {
      sectorBase = "Sector base", raw = "Updated raw sector",
      writeTransactions = "Write transactions", tags = "Sector tags", channels = "Channels",
    },
    fields = {
      sectorBase = G.step_path("write-select", { "value" }),
      raw = G.step_path("write-edit", { "encoded" }),
      writeTransactions = G.step_path("write-commit", { "settledActions" }),
      tags = tag_projection("write"),
      channels = { kind = "repeated-layout", step = "write-verified-records", item = CHANNEL_RECORD_PROJECTION },
    },
  },
}

local MAINTENANCE = {
  kind = "poll", operation = "ping", intervalMs = 200.0,
  maximumInterTransactionGapMs = 300.0, releaseAfterIdleMs = 30000.0,
  timing = "idle-reset", onFailure = "mode-recovery",
}

local STATE_CELLS = G.array({
  {
    id = "device_identity", label = "Device identity",
    description = "The last identity returned by Get device information.",
    valueKind = "string",
    source = { kind = "operation-result", mode = "transfer", operation = "get_device_info", path = G.array({ "identity" }) },
    refresh = { kind = "manual" }, staleAfterMs = pdrv.null,
  },
  {
    id = "firmware_version", label = "Firmware version",
    description = "The last firmware version returned by Get device information.",
    valueKind = "string",
    source = { kind = "operation-result", mode = "transfer", operation = "get_device_info", path = G.array({ "firmware" }) },
    refresh = { kind = "manual" }, staleAfterMs = pdrv.null,
  },
  {
    id = "status_raw", label = "Raw status",
    description = "The last two opaque status octets returned by Get status; no field meaning is assigned.",
    valueKind = "bytes",
    source = { kind = "operation-result", mode = "transfer", operation = "get_status", path = G.array({ "raw" }) },
    refresh = { kind = "manual" }, staleAfterMs = pdrv.null,
  },
})

local TRANSFER_MODE = {
  label = "Programming transfer",
  description = "Use the detachable programming cable to identify the radio and transfer its documented memory structures.",
  protocol = PROTOCOL_MODE,
  establishment = ESTABLISHMENT,
  connectionProfiles = G.array({ CONNECTION }),
  operations = G.array({ GET_DEVICE_INFO, GET_STATUS, PING, READ_CHANNELS, WRITE_CHANNELS }),
  maintenance = MAINTENANCE,
}

local DEVICE = {
  apiVersion = "device/v1",
  module = {
    id = "d1-chan",
    displayName = "D1-CHAN",
    description = "Inspect identity, firmware, status, and the 250-record channel configuration. A channel write replaces one guarded 4,096-byte configuration sector and verifies it by reading it back.",
  },
  modes = { transfer = TRANSFER_MODE },
  storedLayouts = { channel = CHANNEL_LAYOUT },
  carrierActions = {
    ["read-range-chunk"] = READ_RANGE,
    ["write-range-chunk"] = WRITE_RANGE,
  },
  transfers = { ["memory-range"] = MEMORY_RANGE },
  stateCells = STATE_CELLS,
}

return DEVICE, {}
